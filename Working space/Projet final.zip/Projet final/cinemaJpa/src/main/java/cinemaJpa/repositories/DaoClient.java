package cinemaJpa.repositories;

import cinemaJpa.entities.Client;

public interface DaoClient extends DaoGeneric<Client, Long>{

}
