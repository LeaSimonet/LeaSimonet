package cinemaJpa.repositories;

import cinemaJpa.entities.Film;

public interface DaoFilm extends DaoGeneric<Film, Long>{

}
