package cinemaJpa.entities;

public enum Categorie {
	
	Action,
	Animation,
	Aventure,
	Biopic,
	Comedie,
	ComedieDramatique,
	ComedieMusicale,
	Documentaire,
	Drame,
	EpouvanteHorreur,
	Espionnage,
	Famille,
	Fantastique,
	Guerre,
	Historique,
	Judiciaire,
	Policier,
	Romance,
	ScienceFiction,
	Thriller,
	Western;
	
}
