package cinemaJpa.repositories;

import cinemaJpa.entities.Admin;

public interface DaoAdmin extends DaoGeneric<Admin, Long>{

}
