package cinemaJpa.repositories;

import cinemaJpa.entities.Evaluation;
import cinemaJpa.entities.EvaluationKey;

public interface DaoEvaluation extends DaoGeneric<Evaluation, EvaluationKey> {

}
