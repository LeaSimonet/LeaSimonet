package cinemaJpa.entities;

public enum Langue {
	
	VO,VF,VOSTFR;
}