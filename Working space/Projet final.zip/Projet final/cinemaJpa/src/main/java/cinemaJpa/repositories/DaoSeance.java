package cinemaJpa.repositories;

import cinemaJpa.entities.Seance;

public interface DaoSeance extends DaoGeneric<Seance, Long>{

}
