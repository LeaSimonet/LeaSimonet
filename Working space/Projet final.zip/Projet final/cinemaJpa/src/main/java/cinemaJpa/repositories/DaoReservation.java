package cinemaJpa.repositories;

import cinemaJpa.entities.Reservation;

public interface DaoReservation extends DaoGeneric<Reservation, Long> {
	

}
