package cinemaJpa.entities;

public enum Statut {
	etudiant,PMR,retraite,enfant,chomage,RAS;
}
