package cinemaJpa.repositories;

import cinemaJpa.entities.Salle;

public interface DaoSalle extends DaoGeneric<Salle, Long>{

}
